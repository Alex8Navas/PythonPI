# Redondear potencia. 

def potencia2(n1, n2):

	print("El resultado de la potencia de", n1, "elevado a", n2, "es:", n1**n2)

def redond2(n1):

	print("El valor redondeado de", n1, "es:", round(n1))