# Cálculos Genéricos. 

def sumar(n1, n2):

	print("El resultado de la suma de", n1, "más", n2, "es:", n1+n2)

def restar(n1, n2):

	print("El resultado de la resta de", n1, "menos", n2, "es:", n1-n2)

def producto(n1, n2):

	print("El resultado del producto de", n1, "por", n2, "es:", n1*n2)

def divis(n1, n2):

	print("El resultado de la división de", n1, "entre", n2, "es:", n1/n2)

def potencia(n1, n2):

	print("El resultado de la potencia de", n1, "elevado a", n2, "es:", n1**n2)

def redond(n1):

	print("El valor redondeado de", n1, "es:", round(n1))
